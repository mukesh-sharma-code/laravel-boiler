<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Exception;
use App\Models\Post;
use Illuminate\Support\Carbon;
use DataTables;
use PDO;

class PostController extends Controller
{
    public function savePost(Request $req){
        $success = 1;
        $message = "Post Created Succefully";
        $response = [];
        try{
            $post = new Post();
            if($req->postTitle == '' ||  !$req->postTitle){
                throw new Exception("Please enter Post title..");
            }
            if(!$req->postId){
                $post->id = $req->postId;    
                $post->title = $req->postTitle;
                $post->description = $req->postDesc;
                $post->created_at = Carbon::now();
                $post->updated_at = Carbon::now();
                $post->save();
            }else{
                $message = "Post Updated Successfully";
                Post::where('id', $req->postId)
                        ->update([
                        'title' => $req->postTitle,
                        'description' => $req->postDesc
                        ]);
            }
        }catch(Exception $e){
            $message =  $e->getMessage();
            $success = 0;
        }
        $response['success'] = $success;
        $response['message'] = $message;
        echo json_encode($response);
        return ;
    }
    public function getPostGridData(Request $request){
        try{
            if ($request->ajax()) {
                $data = Post::select('*')->get();
                return DataTables::of($data)
                    ->addIndexColumn()
                    ->addColumn('Edit', function($row){
                        $editBtn = '<form action="editPost"><input type="hidden" name="postId" value="'.$row->id.'" /><button class="delete btn btn-primary btn-sm">Edit</button></form>';
                        return $editBtn;
                    })
                    ->addColumn('Delete', function($row){
                        $dltBtn = '<a href="deletePost/'.$row->id.'" class="btn btn-danger btn-sm">Delete</a>';
                        return $dltBtn;
                    })
                    ->rawColumns(['Edit','Delete'])
                    ->make(true);
            }
        }catch(Exception $e){
            Log::error($e->getMessage());
        }
    }
    public function editPost(Request $req){
        $post = Post::find($req->postId);
    
        return view('createPost',compact('post'));
    }
    public function deletePost($id){
        $success = 1;
        $message = "";
        try{
            Post::where("id","=",$id)->delete();
            $message = "Post succesfully deleted";
        }catch(Exception $e){
            $success = 0;
            $message = $e->getMessage();
        }
        
        return redirect()->back()->with(['message'=> $message,'success'=>$success]);
    }
    public function createPost(){
        $post = new Post;
        return view('createPost',compact('post'));
    }
}
