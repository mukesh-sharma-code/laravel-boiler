<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\User;
use Exception;
use Hash;
use Log;
use Symfony\Component\HttpFoundation\Session\Session;

class AuthController extends Controller
{
    public function login(Request $request){ 
        $success = 0;
        $message = "Wrong credentials";
        $response = [];
        $input = $request->all();
        if (auth()->attempt(array('email' => $input['email'],'password' => $input['password']))) {
            if(auth()->user()->isadmin == 1){
                $success = 1;
                $message = "Logged in successfully";
            }else{
                $success = 0;
            }
        }
        $response['success'] = $success;
        $response['message'] = $message;
        echo json_encode($response);
        return ;
    }
    public function signup(Request $req)
    {
        try{
            $success = 1;
            $response = [];
            $message = "Please enter right info.";
            if($req->userName == '' || $req->userName == null || !filter_var($req->email, FILTER_VALIDATE_EMAIL) || $req->password == '' || $req->password == null){
                throw new Exception($message);
            }
            $user = new User();
            $user->name = $req->userName;
            $user->email = $req->email;
            $user->password = Hash::make($req->password);
            $user->isadmin = 1;
            $user->save();
            $message = "User Created Successfully";
        }catch(Exception $e){
            $success = 0;
            Log::error($e->getMessage());
            $message = $e->getMessage();
            if(isset($e->errorInfo[1]) && $e->errorInfo[1] == '1062'){
                $message = "User Already exits";
            }
        }
        $response['success'] = $success;
        $response['message'] = $message;
        echo json_encode($response);
        return ;
    }
    public function logout(){
        Auth::logout();
        return redirect('/login');
    }
}
