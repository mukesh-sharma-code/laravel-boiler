console.log("myjs")
$(document).ready(function(){
    
   
    $("#createProjectForm #workersDD").select2({
        // ajax: {
        //     url: '/task1/loadWorkersDD',
        //     dataType: 'json',
        //     delay: 250,
        //     data: function(params) {
        //      return {
        //        q: params.term, // search term
        //        page: params.page
        //      };
        //     },
        //    minimumInputLength: 0, // so here is a trick 0 will trigger ajax call right when you click on field
        //    processResults: function(data, params) {
        //      //process your results  
        //    },
        // }
    })
})